A bare minimum [HTML](https://en.wikipedia.org/wiki/HTML) page demonstrating use of [CSS](https://en.wikipedia.org/wiki/CSS) and [JavaScript](https://en.wikipedia.org/wiki/JavaScript).

See also [React Starter](https://vizhub.com/curran/c3b14112dae34ef395999cef5783324f).
